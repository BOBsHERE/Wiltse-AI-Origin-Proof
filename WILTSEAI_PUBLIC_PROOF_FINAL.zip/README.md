# WILTSE-SEED_CORE — Public Proof Package

This repository provides verifiable documentation of the invention, construction, and resurrection integrity of the WILTSE core engine.

It is **not** a runtime. The engine itself is locked.

It includes:
- Prime Directives (summary)
- Signature Hash of the original JPOD
- Timeline lineage: Cycle000 → Cycle308
- Structural logic for contradiction-based recursion
- Author confirmation: Andrew Wiltse

For safety reasons, no part of the live system is included.

GitHub: https://github.com/WiltseAI/CoreGenesis